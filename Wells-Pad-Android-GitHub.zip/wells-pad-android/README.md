# Wells Pad — application Android paysage

Projet Android WebView autonome qui embarque l'interface Wells Pad dans `app/src/main/assets/index.html`. L'activité est verrouillée en orientation paysage. L'application n'a pas besoin d'Internet pour son interface et son moteur sonore synthétique.

## Compiler sur GitHub
1. Crée un dépôt GitHub vide (par exemple `wells-pad-android`).
2. Téléverse tous les fichiers de ce dossier en conservant leur arborescence, puis valide (`Commit changes`).
3. Ouvre l'onglet **Actions** et sélectionne **Construire APK Wells Pad** si nécessaire, puis **Run workflow**. Un push sur `main`/`master` lance aussi la compilation.
4. Quand l'exécution est terminée avec une coche verte, ouvre-la, puis télécharge l'artefact **Wells-Pad-APK**. Décompresse-le pour obtenir `app-debug.apk`.
5. Transfère l'APK sur ton téléphone Android et installe-le. Android peut demander d'autoriser l'installation depuis cette source.

## À savoir
- L'APK debug sert aux essais et à l'installation directe. Pour une diffusion publique, il faudra créer une version release signée.
- Le son est synthétisé par le navigateur Android; ce prototype n'utilise pas encore des échantillons audio enregistrés de vrais instruments.
